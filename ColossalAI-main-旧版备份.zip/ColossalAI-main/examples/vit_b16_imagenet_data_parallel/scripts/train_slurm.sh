#!/usr/bin/env bash

python train.py --host $HOST --config ./config.py --port 29500