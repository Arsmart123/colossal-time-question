#!/usr/bin/env python
# -*- encoding: utf-8 -*-

parallel = dict(
    pipeline=dict(size=2),
    tensor=dict(
        size=8,
        mode='3d'
    )
)
