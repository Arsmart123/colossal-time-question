from .model_from_config import ModelFromConfig

__all__ = ['ModelFromConfig']
