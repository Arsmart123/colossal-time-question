colossalai.context.process\_group\_initializer.initializer\_2d
==============================================================

.. automodule:: colossalai.context.process_group_initializer.initializer_2d
   :members:
