colossalai.context.process\_group\_initializer.initializer\_3d
==============================================================

.. automodule:: colossalai.context.process_group_initializer.initializer_3d
   :members:
