colossalai.utils.activation\_checkpoint
=======================================

.. automodule:: colossalai.utils.activation_checkpoint
   :members:
