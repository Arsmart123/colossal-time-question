colossalai.trainer.metric
=========================

.. automodule:: colossalai.trainer.metric
   :members:
