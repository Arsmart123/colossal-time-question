colossalai.constants
====================

.. automodule:: colossalai.constants
   :members:
