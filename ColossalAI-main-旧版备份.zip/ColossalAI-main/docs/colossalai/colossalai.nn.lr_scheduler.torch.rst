colossalai.nn.lr\_scheduler.torch
=================================

.. automodule:: colossalai.nn.lr_scheduler.torch
   :members:
