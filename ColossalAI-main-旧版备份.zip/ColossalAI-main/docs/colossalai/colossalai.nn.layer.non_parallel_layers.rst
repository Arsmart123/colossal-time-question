colossalai.nn.layer.non\_parallel\_layers
======================================

.. automodule:: colossalai.nn.layer.non_parallel_layers
   :members:
