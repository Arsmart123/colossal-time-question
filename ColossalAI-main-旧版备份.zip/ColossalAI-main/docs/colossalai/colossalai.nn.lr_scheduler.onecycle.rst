colossalai.nn.lr\_scheduler.onecycle
====================================

.. automodule:: colossalai.nn.lr_scheduler.onecycle
   :members:
