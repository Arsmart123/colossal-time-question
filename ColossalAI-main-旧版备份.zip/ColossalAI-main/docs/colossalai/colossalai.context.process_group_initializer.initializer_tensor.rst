colossalai.context.process\_group\_initializer.initializer\_tensor
==================================================================

.. automodule:: colossalai.context.process_group_initializer.initializer_tensor
   :members:
