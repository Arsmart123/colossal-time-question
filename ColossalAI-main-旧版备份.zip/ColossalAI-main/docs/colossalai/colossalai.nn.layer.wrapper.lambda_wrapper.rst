colossalai.nn.layer.wrapper.lambda\_wrapper
===========================================

.. automodule:: colossalai.nn.layer.wrapper.lambda_wrapper
   :members:
