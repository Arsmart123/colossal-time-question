colossalai.utils.checkpointing
==============================

.. automodule:: colossalai.utils.checkpointing
   :members:
