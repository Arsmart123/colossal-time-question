colossalai.amp.torch\_amp
==========================

.. automodule:: colossalai.amp.torch_amp
      :members:
