colossalai.builder
==================

.. toctree::
   :maxdepth: 2

   colossalai.builder.builder
   colossalai.builder.pipeline


.. automodule:: colossalai.builder
   :members:
