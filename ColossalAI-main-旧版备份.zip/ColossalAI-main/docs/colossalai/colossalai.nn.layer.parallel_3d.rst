colossalai.nn.layer.parallel\_3d
================================

.. toctree::
   :maxdepth: 2

   colossalai.nn.layer.parallel_3d.layers


.. automodule:: colossalai.nn.layer.parallel_3d
   :members:
