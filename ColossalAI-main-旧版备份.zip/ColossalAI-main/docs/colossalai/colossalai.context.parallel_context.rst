colossalai.context.parallel\_context
====================================

.. automodule:: colossalai.context.parallel_context
   :members:
