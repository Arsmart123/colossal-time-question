colossalai.nn.layer.parallel\_3d.layers
=======================================

.. automodule:: colossalai.nn.layer.parallel_3d.layers
   :members:
