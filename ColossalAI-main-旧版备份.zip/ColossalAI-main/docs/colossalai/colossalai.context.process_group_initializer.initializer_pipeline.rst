colossalai.context.process\_group\_initializer.initializer\_pipeline
====================================================================

.. automodule:: colossalai.context.process_group_initializer.initializer_pipeline
   :members:
