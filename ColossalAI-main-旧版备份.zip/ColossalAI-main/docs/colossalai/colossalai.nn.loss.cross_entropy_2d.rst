colossalai.nn.loss.cross\_entropy\_2d
=====================================

.. automodule:: colossalai.nn.loss.cross_entropy_2d
   :members:
