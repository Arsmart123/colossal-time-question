colossalai.nn.optimizer.fused\_adam
===================================

.. automodule:: colossalai.nn.optimizer.fused_adam
   :members:
