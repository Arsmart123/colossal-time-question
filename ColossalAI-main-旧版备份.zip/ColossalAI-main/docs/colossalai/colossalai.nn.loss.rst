colossalai.nn.loss
==================

.. toctree::
   :maxdepth: 2

   colossalai.nn.loss.cross_entropy_2d
   colossalai.nn.loss.cross_entropy_2p5d
   colossalai.nn.loss.cross_entropy_3d


.. automodule:: colossalai.nn.loss
   :members:
