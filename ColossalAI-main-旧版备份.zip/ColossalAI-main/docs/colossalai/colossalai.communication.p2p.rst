colossalai.communication.p2p
============================

.. automodule:: colossalai.communication.p2p
   :members:
