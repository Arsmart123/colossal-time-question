colossalai.nn.lr\_scheduler.multistep
=====================================

.. automodule:: colossalai.nn.lr_scheduler.multistep
   :members:
