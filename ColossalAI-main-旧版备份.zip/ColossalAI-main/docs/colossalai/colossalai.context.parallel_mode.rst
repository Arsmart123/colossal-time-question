colossalai.context.parallel\_mode
=================================

.. automodule:: colossalai.context.parallel_mode
   :members:
