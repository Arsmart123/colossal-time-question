colossalai.nn.lr\_scheduler
===========================

.. toctree::
   :maxdepth: 2

   colossalai.nn.lr_scheduler.cosine
   colossalai.nn.lr_scheduler.delayed
   colossalai.nn.lr_scheduler.linear
   colossalai.nn.lr_scheduler.multistep
   colossalai.nn.lr_scheduler.onecycle
   colossalai.nn.lr_scheduler.poly
   colossalai.nn.lr_scheduler.torch

   
.. automodule:: colossalai.nn.lr_scheduler
   :members:
