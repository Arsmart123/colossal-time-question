colossalai.nn.layer.parallel\_1d
================================

.. toctree::
   :maxdepth: 2

   colossalai.nn.layer.parallel_1d.layers


.. automodule:: colossalai.nn.layer.parallel_1d
   :members:
