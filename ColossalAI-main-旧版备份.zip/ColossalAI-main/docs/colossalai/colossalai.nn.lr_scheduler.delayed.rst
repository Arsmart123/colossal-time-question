colossalai.nn.lr\_scheduler.delayed
===================================

.. automodule:: colossalai.nn.lr_scheduler.delayed
   :members:
