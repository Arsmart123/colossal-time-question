colossalai.amp.naive\_amp
==========================

.. automodule:: colossalai.amp.naive_amp
   :members:
