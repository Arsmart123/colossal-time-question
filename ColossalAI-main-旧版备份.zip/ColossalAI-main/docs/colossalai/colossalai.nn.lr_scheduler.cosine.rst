colossalai.nn.lr\_scheduler.cosine
==================================

.. automodule:: colossalai.nn.lr_scheduler.cosine
   :members:
