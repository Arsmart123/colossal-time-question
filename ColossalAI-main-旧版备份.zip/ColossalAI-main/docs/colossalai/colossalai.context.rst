colossalai.context
==================

.. toctree::
   :maxdepth: 2

   colossalai.context.process_group_initializer
   colossalai.context.random


.. toctree::
   :maxdepth: 2

   colossalai.context.config
   colossalai.context.parallel_context
   colossalai.context.parallel_mode


.. automodule:: colossalai.context
   :members:
