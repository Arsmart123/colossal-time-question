colossalai.nn.layer.parallel\_sequence.layers
=============================================

.. automodule:: colossalai.nn.layer.parallel_sequence.layers
   :members:
