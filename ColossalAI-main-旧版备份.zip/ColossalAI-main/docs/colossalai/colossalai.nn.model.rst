colossalai.nn.model
===================

.. toctree::
   :maxdepth: 2

   colossalai.nn.model.model_from_config
