colossalai.nn.layer.parallel\_2p5d.layers
=========================================

.. automodule:: colossalai.nn.layer.parallel_2p5d.layers
   :members:
