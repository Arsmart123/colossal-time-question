colossalai.nn
=============

.. toctree::
   :maxdepth: 2

   colossalai.nn.layer
   colossalai.nn.loss
   colossalai.nn.lr_scheduler
   colossalai.nn.model
   colossalai.nn.optimizer


.. automodule:: colossalai.nn
   :members:
