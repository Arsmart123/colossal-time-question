colossalai.nn.optimizer.lars
============================

.. automodule:: colossalai.nn.optimizer.lars
   :members:
