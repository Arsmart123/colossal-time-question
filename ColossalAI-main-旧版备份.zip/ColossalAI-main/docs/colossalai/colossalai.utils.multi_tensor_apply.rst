colossalai.nn.multi\_tensor\_apply
==================================

.. automodule:: colossalai.utils.multi_tensor_apply.multi_tensor_apply
   :members:



