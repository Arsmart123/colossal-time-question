colossalai.nn.layer.parallel\_2p5d
==================================

.. toctree::
   :maxdepth: 2

   colossalai.nn.layer.parallel_2p5d.layers


.. automodule:: colossalai.nn.layer.parallel_2p5d
   :members:
