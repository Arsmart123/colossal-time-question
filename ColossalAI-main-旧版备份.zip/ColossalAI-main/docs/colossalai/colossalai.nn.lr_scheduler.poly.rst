colossalai.nn.lr\_scheduler.poly
================================

.. automodule:: colossalai.nn.lr_scheduler.poly
   :members:
