colossalai.nn.layer.parallel\_sequence
======================================

.. toctree::
   :maxdepth: 2

   colossalai.nn.layer.parallel_sequence.layers


.. automodule:: colossalai.nn.layer.parallel_sequence
   :members:
