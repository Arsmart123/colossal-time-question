colossalai.context.process\_group\_initializer
==============================================

.. automodule:: colossalai.context.process_group_initializer
   :members:


.. toctree::
   :maxdepth: 2

   colossalai.context.process_group_initializer.initializer_1d
   colossalai.context.process_group_initializer.initializer_2d
   colossalai.context.process_group_initializer.initializer_2p5d
   colossalai.context.process_group_initializer.initializer_3d
   colossalai.context.process_group_initializer.initializer_data
   colossalai.context.process_group_initializer.initializer_pipeline
   colossalai.context.process_group_initializer.initializer_sequence
   colossalai.context.process_group_initializer.initializer_tensor
   colossalai.context.process_group_initializer.process_group_initializer
