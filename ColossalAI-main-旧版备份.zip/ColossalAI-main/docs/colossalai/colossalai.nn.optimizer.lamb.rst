colossalai.nn.optimizer.lamb
============================

.. automodule:: colossalai.nn.optimizer.lamb
   :members:
