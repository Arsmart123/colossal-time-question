colossalai.nn.layer.parallel\_1d.layers
=======================================

.. automodule:: colossalai.nn.layer.parallel_1d.layers
   :members:
