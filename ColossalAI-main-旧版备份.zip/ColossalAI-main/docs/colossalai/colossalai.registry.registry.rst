colossalai.registry.registry
============================

.. automodule:: colossalai.registry.registry
   :members:
