colossalai.context.process\_group\_initializer.process\_group\_initializer
==========================================================================

.. automodule:: colossalai.context.process_group_initializer.process_group_initializer
   :members:
