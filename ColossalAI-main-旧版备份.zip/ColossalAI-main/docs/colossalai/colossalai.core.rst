colossalai.core
===============

.. automodule:: colossalai.core
   :members:
