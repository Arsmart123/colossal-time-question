colossalai.nn.layer.parallel\_2d.layers
=======================================

.. automodule:: colossalai.nn.layer.parallel_2d.layers
   :members:
