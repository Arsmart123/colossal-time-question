colossalai.registry
===================

.. toctree::
   :maxdepth: 2

   colossalai.registry.registry


.. automodule:: colossalai.registry
   :members:
