colossalai.nn.optimizer.fused\_lamb
===================================

.. automodule:: colossalai.nn.optimizer.fused_lamb
   :members:
