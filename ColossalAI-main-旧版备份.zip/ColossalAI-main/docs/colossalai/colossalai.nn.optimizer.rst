colossalai.nn.optimizer
=======================

.. toctree::
   :maxdepth: 2

   colossalai.nn.optimizer.fused_adam
   colossalai.nn.optimizer.fused_lamb
   colossalai.nn.optimizer.fused_sgd
   colossalai.nn.optimizer.lamb
   colossalai.nn.optimizer.lars


.. automodule:: colossalai.nn.optimizer
   :members:
