colossalai.context.process\_group\_initializer.initializer\_sequence
====================================================================

.. automodule:: colossalai.context.process_group_initializer.initializer_sequence
   :members:
