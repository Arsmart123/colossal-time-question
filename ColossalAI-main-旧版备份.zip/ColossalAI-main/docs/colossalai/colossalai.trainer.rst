colossalai.trainer
==================

.. toctree::
   :maxdepth: 2

   colossalai.trainer.hooks


.. toctree::
   :maxdepth: 2

   colossalai.trainer.metric


.. automodule:: colossalai.trainer
   :members:
