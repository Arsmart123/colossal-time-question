colossalai.nn.layer.wrapper
===========================

.. automodule:: colossalai.nn.layer.wrapper
   :members:


.. toctree::
   :maxdepth: 2

   colossalai.nn.layer.wrapper.lambda_wrapper
