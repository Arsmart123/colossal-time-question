colossalai.utils.timer
======================

.. automodule:: colossalai.utils.timer
   :members:
