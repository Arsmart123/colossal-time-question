colossalai.builder.pipeline
===========================

.. automodule:: colossalai.builder.pipeline
   :members:
