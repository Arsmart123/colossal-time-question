colossalai.nn.optimizer.fused\_sgd
==================================

.. automodule:: colossalai.nn.optimizer.fused_sgd
   :members:
