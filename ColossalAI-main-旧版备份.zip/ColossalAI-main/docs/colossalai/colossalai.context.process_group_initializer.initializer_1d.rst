colossalai.context.process\_group\_initializer.initializer\_1d
==============================================================

.. automodule:: colossalai.context.process_group_initializer.initializer_1d
   :members:
