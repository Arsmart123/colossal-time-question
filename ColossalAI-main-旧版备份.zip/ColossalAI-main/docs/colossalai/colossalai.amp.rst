colossalai.amp
==================

.. toctree::
   :maxdepth: 2

   colossalai.amp.torch_amp
   colossalai.amp.apex_amp
   colossalai.amp.naive_amp


.. automodule:: colossalai.amp
   :members:
