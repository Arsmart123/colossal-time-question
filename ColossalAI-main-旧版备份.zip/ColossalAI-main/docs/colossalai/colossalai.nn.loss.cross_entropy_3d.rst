colossalai.nn.loss.cross\_entropy\_3d
=====================================

.. automodule:: colossalai.nn.loss.cross_entropy_3d
   :members:
