colossalai.nn.lr\_scheduler.linear
==================================

.. automodule:: colossalai.nn.lr_scheduler.linear
   :members:
