colossalai.utils.common
=======================

.. automodule:: colossalai.utils.common
   :members:
