colossalai.nn.layer.parallel\_2d
================================

.. toctree::
   :maxdepth: 2

   colossalai.nn.layer.parallel_2d.layers


.. automodule:: colossalai.nn.layer.parallel_2d
   :members:
