colossalai.nn.layer.base\_layer
===============================

.. automodule:: colossalai.nn.layer.base_layer
   :members:
