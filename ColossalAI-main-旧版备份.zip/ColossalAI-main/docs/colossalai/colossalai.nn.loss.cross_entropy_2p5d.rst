colossalai.nn.loss.cross\_entropy\_2p5d
=======================================

.. automodule:: colossalai.nn.loss.cross_entropy_2p5d
   :members:
