colossalai.nn.layer
===================

.. toctree::
   :maxdepth: 2

   colossalai.nn.layer.parallel_1d
   colossalai.nn.layer.parallel_2d
   colossalai.nn.layer.parallel_2p5d
   colossalai.nn.layer.parallel_3d
   colossalai.nn.layer.parallel_sequence
   colossalai.nn.layer.non_parallel_layers
   colossalai.nn.layer.wrapper
   colossalai.nn.layer.base_layer


.. automodule:: colossalai.nn.layer
   :members:
