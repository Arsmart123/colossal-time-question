colossalai.context.process\_group\_initializer.initializer\_data
================================================================

.. automodule:: colossalai.context.process_group_initializer.initializer_data
   :members:
