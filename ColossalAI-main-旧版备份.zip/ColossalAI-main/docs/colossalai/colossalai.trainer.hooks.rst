colossalai.trainer.hooks
========================

.. automodule:: colossalai.trainer.hooks
   :members:
