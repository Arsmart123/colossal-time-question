colossalai.nn.model.model\_from\_config
===============================

.. automodule:: colossalai.nn.model.model_from_config
   :members:
